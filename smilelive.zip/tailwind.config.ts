// tailwind.config.js

module.exports = {
  theme: {
    extend: {
      colors: {
        customPink: '#F59DA5',
      },
    },
  },
};